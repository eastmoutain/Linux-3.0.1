#ifndef __AV_WRAPPER_H
#define __AV_WRAPPER_H

#ifdef __cplusplus
extern "C" {
#endif

#include "avutil.h"
#include "avformat.h"
#include "avcodec.h"

#ifdef __cplusplus
}
#endif

#endif
