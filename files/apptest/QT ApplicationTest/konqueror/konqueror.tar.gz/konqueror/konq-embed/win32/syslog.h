#ifndef __syslog_h__
#define __syslog_h__

// ### REMOVEME!!! just for testing
int vsnprintf( char *, int, const char *, ... ) { return 0; }

#endif
