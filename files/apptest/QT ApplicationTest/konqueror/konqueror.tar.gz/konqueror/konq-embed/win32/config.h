#define HAVE_SYS_STAT_H
#define MAXPATHLEN 254
#define KDEDIR ""
#define HAVE_SSL
#define HAVE_SYS_TIMEB_H 1
#define HAVE_FLOAT_H 1
#define HAVE_STRING_H 1
#define KONQ_GUI_X11
#define HAVE_LIBJPEG
#define HAVE_PCREPOSIX
#define ENABLE_JAVASCRIPT 1
#define KJS_SWAPPED_CHAR 1
// ### wrong place, but this way http.cc and krfcdate get it...
#define strncasecmp qstrnicmp
