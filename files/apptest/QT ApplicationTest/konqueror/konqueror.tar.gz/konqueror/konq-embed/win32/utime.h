#ifndef __utime_h__
#define __utime_h__

// hmm...
void utime( const char *, void * ) {}

#endif
