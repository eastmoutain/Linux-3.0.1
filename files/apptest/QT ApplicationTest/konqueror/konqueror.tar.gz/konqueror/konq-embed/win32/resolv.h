#ifndef __resolv_h__
#define __resolv_h__

#endif

