/* automatically generated from math.table. DO NOT EDIT ! */

namespace KJS {

const struct HashEntry2 mathTableEntries[] = {
   { "atan", Math::ATan, 0, &mathTableEntries[25] },
   { 0, 0, 0, 0 },
   { "SQRT2", Math::Sqrt2, 0, &mathTableEntries[23] },
   { 0, 0, 0, 0 },
   { 0, 0, 0, 0 },
   { 0, 0, 0, 0 },
   { "E", Math::Euler, 0, &mathTableEntries[21] },
   { "asin", Math::ASin, 0, &mathTableEntries[26] },
   { "atan2", Math::ATan2, 0, &mathTableEntries[32] },
   { "LOG2E", Math::Log2E, 0, &mathTableEntries[27] },
   { "cos", Math::Cos, 0, 0 },
   { "max", Math::Max, 0, &mathTableEntries[29] },
   { 0, 0, 0, 0 },
   { 0, 0, 0, 0 },
   { "LOG10E", Math::Log10E, 0, &mathTableEntries[24] },
   { "LN2", Math::Ln2, 0, &mathTableEntries[31] },
   { "abs", Math::Abs, 0, 0 },
   { "sqrt", Math::Sqrt, 0, 0 },
   { "exp", Math::Exp, 0, 0 },
   { 0, 0, 0, 0 },
   { "LN10", Math::Ln10, 0, &mathTableEntries[22] },
   { "PI", Math::Pi, 0, &mathTableEntries[28] },
   { "SQRT1_2", Math::Sqrt1_2, 0, 0 },
   { "acos", Math::ACos, 0, 0 },
   { "ceil", Math::Ceil, 0, 0 },
   { "floor", Math::Floor, 0, 0 },
   { "log", Math::Log, 0, 0 },
   { "min", Math::Min, 0, 0 },
   { "pow", Math::Pow, 0, &mathTableEntries[30] },
   { "random", Math::Random, 0, 0 },
   { "round", Math::Round, 0, 0 },
   { "sin", Math::Sin, 0, 0 },
   { "tan", Math::Tan, 0, 0 }
};

const struct HashTable2 mathTable = { 2, 33, mathTableEntries, 21 };

}; // namespace
