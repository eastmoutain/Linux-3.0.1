#include <string.h>
void *_dlsym(const char *sym)
{
#include "static-syms.h"
	return NULL;
}
