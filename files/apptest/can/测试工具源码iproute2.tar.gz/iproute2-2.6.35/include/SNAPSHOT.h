static const char SNAPSHOT[] = "100804";
